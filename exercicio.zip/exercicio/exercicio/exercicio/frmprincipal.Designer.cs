﻿namespace exercicio
{
    partial class frmprincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btnsair = new System.Windows.Forms.Button();
            this.PicbCli = new System.Windows.Forms.PictureBox();
            this.Picbjogos = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicbCli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picbjogos)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 311);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cadastro de jogos ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(541, 311);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Cadastro de cliente";
            // 
            // Btnsair
            // 
            this.Btnsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnsair.Location = new System.Drawing.Point(665, 399);
            this.Btnsair.Name = "Btnsair";
            this.Btnsair.Size = new System.Drawing.Size(90, 39);
            this.Btnsair.TabIndex = 4;
            this.Btnsair.Text = "Sair";
            this.Btnsair.UseVisualStyleBackColor = true;
            this.Btnsair.Click += new System.EventHandler(this.Btnsair_Click);
            // 
            // PicbCli
            // 
            this.PicbCli.Image = global::exercicio.Properties.Resources.cliente;
            this.PicbCli.Location = new System.Drawing.Point(546, 95);
            this.PicbCli.Name = "PicbCli";
            this.PicbCli.Size = new System.Drawing.Size(176, 197);
            this.PicbCli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicbCli.TabIndex = 1;
            this.PicbCli.TabStop = false;
            this.PicbCli.Click += new System.EventHandler(this.PicbCli_Click);
            // 
            // Picbjogos
            // 
            this.Picbjogos.Image = global::exercicio.Properties.Resources.jogos;
            this.Picbjogos.Location = new System.Drawing.Point(42, 95);
            this.Picbjogos.Name = "Picbjogos";
            this.Picbjogos.Size = new System.Drawing.Size(176, 197);
            this.Picbjogos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Picbjogos.TabIndex = 0;
            this.Picbjogos.TabStop = false;
            this.Picbjogos.Click += new System.EventHandler(this.Picbjogos_Click);
            // 
            // frmprincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btnsair);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PicbCli);
            this.Controls.Add(this.Picbjogos);
            this.Name = "frmprincipal";
            this.Text = "Cadastro de sistema";
            ((System.ComponentModel.ISupportInitialize)(this.PicbCli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picbjogos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Picbjogos;
        private System.Windows.Forms.PictureBox PicbCli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btnsair;
    }
}

