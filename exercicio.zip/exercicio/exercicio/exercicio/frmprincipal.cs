﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercicio
{
    public partial class frmprincipal : Form
    {
        public frmprincipal()
        {
            InitializeComponent();
        }

        private void Picbjogos_Click(object sender, EventArgs e)
        {
            FrmJogos jogos = new FrmJogos();
            jogos.Show();
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PicbCli_Click(object sender, EventArgs e)
        {
            FrmCliente cliente = new FrmCliente();
            cliente.Show();
        }
    }
}
