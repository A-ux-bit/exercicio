﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercicio
{
    public partial class FrmJogos : Form
    {
        public FrmJogos()
        {
            InitializeComponent();
        }

        private void jogosBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.jogosBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet2);

        }

        private void FrmJogos_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'dataSet2.jogos'. Você pode movê-la ou removê-la conforme necessário.
            this.jogosTableAdapter.Fill(this.dataSet2.jogos);

        }
    }
}
